/*
-------------------------------------------------------------
Author Name: Karan Kumar Agarwal

Date:24-Sep-2021

Purpose /Description: This Class for loading config file and
	creating the using of selenium and appium.
-------------------------------------------------------------

 */
package CommonUtility;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateSession {

	DemoAutomationConfiguration automationConfiguration;
	public static ThreadLocal<DemoAutomationConfiguration> tac = new ThreadLocal<DemoAutomationConfiguration>();


	/**
	 * method to read the Config File and launch drivers according to configuration
	 * @throws InterruptedException 
	 *
	 */
	public void readConfigFile(String path,String Platform) throws IOException{
		automationConfiguration = new DemoAutomationConfiguration();
		automationConfiguration.Platform = Platform;
		System.out.println("Start reading config file");

		String pathforconfig=System.getProperty("user.dir").toString()+path.toString();
		automationConfiguration.Propertyfile = new PropertyFile(pathforconfig.toString());
		automationConfiguration.DesiredCap = new DesiredCapabilities();

		automationConfiguration.ScreenshotFor = automationConfiguration.Propertyfile.getProperty("screenshotfor").toString();
		automationConfiguration.LaunchBrowser = automationConfiguration.Propertyfile.getProperty("launchbrowser").toString();
		automationConfiguration.LaunchMobileApp = automationConfiguration.Propertyfile.getProperty("launchmobileapp").toString();
		System.out.println("Read Complete property file.");

		if(automationConfiguration.LaunchBrowser.toUpperCase().equals("TRUE")){
			launchWebDriver(automationConfiguration.Propertyfile);
		}if(automationConfiguration.LaunchMobileApp.toUpperCase().equals("TRUE")){
			System.out.println("Starting launching mobile app ");
			if(Platform.toUpperCase().equals("ANDROID")){
				System.out.println("Platform: Android");
				launchAndroidDriver(automationConfiguration.Propertyfile);
			}else if(Platform.toString().toUpperCase().equals("IOS")){
				System.out.println("Platform: IOS");
				launchiOSDriver(automationConfiguration.Propertyfile);
			}else{
				//AutomationConfiguration.logInfo("Platform name is invalid cannot launch any test.");
			}
		}
		tac.set(automationConfiguration);

	}

	public static synchronized DemoAutomationConfiguration getAutomationConfiguration() {
		return tac.get();
	}


	/**
	 * method to launch the android driver
	 *
	 *@param capabilities to give the desiredcapabilities
	 */

	public synchronized void launchAndroidDriver(PropertyFile propertyfile) throws MalformedURLException{		
		try {
			String env="";
			try {
				if(System.getProperty("environment").length()==0){
					env="";
				}else {
					env = System.getProperty("environment").toUpperCase();
				}
			}catch(Exception e) {
				env="";
			}

			automationConfiguration.DesiredCap.setCapability("deviceName", propertyfile.getProperty("deviceName").toString());
			automationConfiguration.DesiredCap.setCapability("platformName",propertyfile.getProperty("platformName").toString());
			automationConfiguration.DesiredCap.setCapability("appActivity", propertyfile.getProperty("appActivity").toString());
			automationConfiguration.DesiredCap.setCapability("app",new File( propertyfile.getProperty(env+"app").toString()).getAbsolutePath());
			automationConfiguration.DesiredCap.setCapability(MobileCapabilityType.FULL_RESET, true);
			automationConfiguration.DesiredCap.setCapability("automationName", propertyfile.getProperty("automationName").toString());
			automationConfiguration.DesiredCap.setCapability("uiautomator2ServerLaunchTimeout",Integer.parseInt(propertyfile.getProperty("uiautomator2ServerLaunchTimeout")));
			automationConfiguration.DesiredCap.setCapability("appWaitDuration",Integer.parseInt(propertyfile.getProperty("appWaitDuration")));
			automationConfiguration.DesiredCap.setCapability("udid", propertyfile.getProperty("udid").toString());
			automationConfiguration.DesiredCap.setCapability("adbExecTimeout", 25000);
			automationConfiguration.DesiredCap.setCapability("autoGrantPermissions", true);

			automationConfiguration.AppiumServerURL = propertyfile.getProperty("appiumserverurl").toString();
			for(int i=0;i<5;i++) {
				try {
					automationConfiguration.AppiumDriver = new AndroidDriver<>(new URL(automationConfiguration.AppiumServerURL), automationConfiguration.DesiredCap);
					//AndroidDriver driver = (AndroidDriver) new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"),
					//		AutomationConfiguration.DesiredCap);
					break;
				}catch(Exception e) {
					System.out.println(e.toString());
					automationConfiguration.DesiredCap.setCapability("appWaitDuration",Integer.parseInt((String) automationConfiguration.DesiredCap.getCapability("appWaitDuration"))+3000);
					Thread.sleep(3000);
				}
			}
			automationConfiguration.AppiumDriver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			//AutomationConfiguration.logInfo("Successfully launched android app");	
		}catch(Exception e){
			System.out.println(e.toString());
			//AutomationConfiguration.logInfo("Error in launching android app. Exception: "+e.toString());
		}
	}


	/**
	 * method to launch the IOS driver
	 *
	 *@param capabilities to give the desiredcapabilities
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public synchronized void launchiOSDriver(PropertyFile propertyfile) throws IOException {

		System.out.println("Goind to launch IOS");

		try {
			String env="";
			try {
				if(System.getProperty("environment").length()==0){
					env="";
				}else {
					env = System.getProperty("environment").toUpperCase();
				}
			}catch(Exception e) {
				env="";
			}
			automationConfiguration.DesiredCap = new DesiredCapabilities();

			automationConfiguration.DesiredCap.setCapability("udid", propertyfile.getProperty("iosudid").toString());
			automationConfiguration.DesiredCap.setCapability("deviceName", propertyfile.getProperty("iosdeviceName").toString());
			automationConfiguration.DesiredCap.setCapability("platformName",propertyfile.getProperty("iosplatformName").toString());
			automationConfiguration.DesiredCap.setCapability("automationName", propertyfile.getProperty("iosautomationName").toString());
			automationConfiguration.DesiredCap.setCapability("app",new File( propertyfile.getProperty(env+"iosapp").toString()).getAbsolutePath());

			automationConfiguration.AppiumDriver  = new AppiumDriver<WebElement>( new URL("http://127.0.0.1:4723/wd/hub"), automationConfiguration.DesiredCap);
		}catch(Exception e) {
			System.out.println(e.toString());
		}

	}

	/**
	 * method to launch the Webdriver for Web App
	 *
	 */
	public void launchWebDriver(PropertyFile propertyfile){
		try {

			automationConfiguration.BrowserName = propertyfile.getProperty("browser").toString();
			automationConfiguration.URL = propertyfile.getProperty("url").toString();
			if(automationConfiguration.BrowserName.toUpperCase().equals("CHROME")){
				//automationConfiguration.logInfo("Launching Chrome browser");
				WebDriverManager.chromedriver().setup();
				ChromeOptions options = new ChromeOptions();
				options.addArguments("use-fake-device-for-media-stream");
				options.addArguments("use-fake-ui-for-media-stream");
				HashMap<String, Object> prefs= new HashMap<String, Object>();
				prefs.put("profile.default_content_setting_values.media_stream_mic", 1);
				prefs.put("profile.default_content_setting_values.media_stream_camera", 1);
				prefs.put("profile.default_content_setting_values.geolocation", 1);
				prefs.put("profile.default_content_setting_values.notifications", 1);
				options.setExperimentalOption("prefs", prefs);
				automationConfiguration.Driver = new ChromeDriver(options);
				automationConfiguration.Driver.manage().window().maximize();
				//automationConfiguration.logInfo("Sucessfully launched Chrome Browser");
			}else if (automationConfiguration.BrowserName.toUpperCase().equals("FIREFOX")){
				//automationConfiguration.logInfo("Launching Firefox browser");
				WebDriverManager.firefoxdriver().setup();
				automationConfiguration.Driver.manage().window().maximize();
				//automationConfiguration.logInfo("Sucessfully launched Firefox Browser");
			}else if (automationConfiguration.BrowserName.toUpperCase().equals("IE")){
				//automationConfiguration.logInfo("Launching Internet Explorer browser");
				WebDriverManager.iedriver().setup();
				automationConfiguration.Driver.manage().window().maximize();
				//AutomationConfiguration.logInfo("Sucessfully launched Internet Explorer Browser");
			}else{
				//AutomationConfiguration.logInfo("Invalid browser type. Cannot launch.");
			}
		}catch(Exception e){
			//AutomationConfiguration.logInfo("Exception in launching browser: "+ e.toString());
		}	

	}
}