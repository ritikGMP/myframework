package CommonUtility;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyFile {
	
	private Properties Propertyfile = new Properties();
	private String path;
	
	public PropertyFile(String path) {
		try {
			this.path = path;
			FileInputStream fis = new FileInputStream(path.toString());
			this.Propertyfile.load(fis);
		}catch(Exception e) {
			System.out.println("Unable to load property file:  "+path+" Error:"+e.toString());
		}
	}
	
	
	public String getProperty(String key) {
		try {
			return Propertyfile.getProperty(key).toString();
		}catch(Exception e) {
			System.out.println("No key ("+key+") is present in the property file. Error: "+e.toString());
		}
		return "";
	}
	
	public String getPathForPropertyFile() {
		return this.path;
	}
	
	public static void main(String []agrs) {
		PropertyFile Propertyfile = new PropertyFile("/Users/apple/Documents/GMP_HybridAutomationFramework-master/src/test/java/resources/Mobile/ConfigFiles/Apcoa.properties");
		System.out.println(Propertyfile.getProperty("iosdeviceName12"));
	}
	

}
