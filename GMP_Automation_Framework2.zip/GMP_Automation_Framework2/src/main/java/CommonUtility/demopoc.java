package CommonUtility;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class demopoc {
	public static void main(String[] args){
		
		//runIOSSimulator();
		runAndroidSimulator();
	}

	
	
	public static void runIOSSimulator() {
		try {
			String cmd = "open -a simulator";
			Process process = Runtime.getRuntime().exec(cmd);
			System.out.println(process.toString());
		}catch(Exception e) {}	
	}
	
	public static void runAndroidSimulator() {
		try {
			String cmd = System.getenv("ANDROID_HOME")+"/emulator/emulator -avd Pixel_5_API_29 ";
			Process process = Runtime.getRuntime().exec(cmd);
			System.out.println(process.toString());
			
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
		    BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

		    StringBuffer stdOut = new StringBuffer();
		    StringBuffer errOut = new StringBuffer();

		    // Read the output from the command:
		    System.out.println("Here is the standard output of the command:\n");
		    String s = null;
		    while ((s = stdInput.readLine()) != null) {
		        System.out.println(s);
		        stdOut.append(s);
		    }

		    // Read any errors from the attempted command:
		    System.out.println("Here is the standard error of the command (if any):\n");
		    while ((s = stdError.readLine()) != null) {
		        System.out.println(s);
		        errOut.append(s);
		    }
		    System.out.println("hi");
		}catch(Exception e) {
			System.out.println(e.toString());
		}	
	}
	
	



}
