package Utility;

import org.openqa.selenium.WebElement;


import CommonUtility.CreateSession;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;


public class GoBackToHomeScreen {
	 
	
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_close') or contains(@resource-id,':id/tv_negative_action_button') or contains(@resource-id,':id/iv_back')]")
	private WebElement close;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_menu')]")
	private WebElement BtnNotification;
	
	AppiumDriver driver;
	public GoBackToHomeScreen()
	{
		this.driver=CreateSession.getAutomationConfiguration().AppiumDriver;
	}
	
	public void GetBackToHomeScreen(int i) throws InterruptedException
	{  
		
		try {
	    	CommonUtility.GenericMethods.explicitWait(driver,close,5);
		  close.click();
	       }
	catch(Exception e)
	{}
		
	   if(checknotificationbtn()||i==10)
	   {   System.out.println("Already at home screen");
		   return;
	   }
	   else
	   {  i++;
		   System.out.println("Not At home Screen");
	      System.out.println("pressing the back button");
		   ((AndroidDriver<WebElement>) driver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	        Thread.sleep(3000);
		   GetBackToHomeScreen(i);
	   }
	
	
	}
	
	public boolean checknotificationbtn()
	{
		try {
			 if(BtnNotification.isDisplayed())
			   {   System.out.println("Already at home screen");
				   return true;
			   }
			 return false;
		}
		catch(Exception e) {
			return false;
		}
	}
	
}
