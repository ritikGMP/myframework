package Utility;

import java.io.IOException;

public class TerminalCommand {
	
	public void excCommand(String check) throws IOException{


		String command ="cp "+System.getProperty("user.dir")+"/"+check+"/poster.png /Users/ritiksharma/Library/Android/sdk/emulator/resources";

		try{Process p = Runtime.getRuntime().exec(command);}catch(Exception e) {System.out.println(e.toString());}

	}

	public void removeQR()
	{ 
		String command ="rm /Users/ritiksharma/Library/Android/sdk/emulator/resources/poster.png";
        
		try{Process p = Runtime.getRuntime().exec(command);}catch(Exception e) {System.out.println(e.toString());}

	}


}
