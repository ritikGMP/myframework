package Mobile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.fasterxml.jackson.databind.ObjectMapper;
import CommonUtility.CreateSession;
import CommonUtility.demopoc;
import DataDriven.ExcelDriven;
import Mobile.ObjectMapper.BuyPassMapper;
import Mobile.ObjectMapper.LoginMapper;
import Pages.Mobile.PageBuyPass;
import Utility.GoBackToHomeScreen;

public class BuyPassCheck {
	
	/**
	 * method to initialize the appium and launch application
	 *  
	 */
	@Parameters({ "Environment", "Country","Tenant","Platform" })
	@BeforeClass
	public void initializeDriver(String environment, String country,String tenant, String platform) throws IOException{
		System.out.println( System.getenv("ANDROID_HOME"));
			//	demopoc.runAndroidSimulator();
				demopoc.runIOSSimulator();
		//AutomationConfiguration.Tenant = tenant;
		//AutomationConfiguration.Environment = ennv;
		//AutomationConfiguration.Country = country;
		//AutomationConfiguration.Platform = platform;
		//AutomationConfiguration.extent.setSystemInfo("Tenant",AutomationConfiguration.Tenant);
		//AutomationConfiguration.extent.setSystemInfo("Environment", AutomationConfiguration.Environment);
		//AutomationConfiguration.extent.setSystemInfo("Country", AutomationConfiguration.Country);
		//AutomationConfiguration.extent.setSystemInfo("Platform", AutomationConfiguration.Platform);
		CreateSession cs = new CreateSession();
		cs.readConfigFile("/src/test/java/resources/Mobile/ConfigFiles/"+tenant+".properties",platform);
		CreateSession.getAutomationConfiguration().Country = System.getProperty("country");
		CreateSession.getAutomationConfiguration().Tenant = System.getProperty("tenant");
		CreateSession.getAutomationConfiguration().Environment = System.getProperty("environment");
		CreateSession.getAutomationConfiguration().Platform = System.getProperty("platform");
	}
	/**
	 * method to end the automation
	 *
	 */
	@AfterClass
	public void Teardown(){
		CreateSession.getAutomationConfiguration().AppiumDriver.quit();
	}
	
	@Test
	public void demo() {
		//demopoc.runAndroidSimulator();
	}
	

	@DataProvider
	public LoginMapper[] getLoginData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Login");	
		ObjectMapper mapper = new ObjectMapper();
		LoginMapper []login = new LoginMapper[1];
		login[0] = mapper.readValue(data, LoginMapper.class);
		return login;	
	}

	/**
	 * method to Select country from the select country page
	 * 
	 */
	@Test(priority=1)
	public void selectCountry() throws Exception{
		SmokePnd spnd = new SmokePnd();
		spnd.selectCountry();
	}


	/**
	 * method to enter credentials and check whether user is able to login or not
	 * @param loginMapper contains information of user credentials and username
	 * 
	 */
	@Test(priority=2,dataProvider="getLoginData")
	public void loginAppcoa(LoginMapper loginMapper) throws InterruptedException{
		SmokePnd spnd = new SmokePnd();
		spnd.loginAppcoa(loginMapper);
	}

	
	@DataProvider
	public BuyPassMapper[] getBuyPassData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"BuyPass");		
		ObjectMapper mapper = new ObjectMapper();
		BuyPassMapper []pass = new BuyPassMapper[1];
		pass[0] = mapper.readValue(data, BuyPassMapper.class);
		return pass;	
	}

	@Test(priority=3,dataProvider = "getBuyPassData")
	public void BuyPass(BuyPassMapper passMapper)throws InterruptedException{
		GoBackToHomeScreen GB=new GoBackToHomeScreen();
		try {
		Thread.sleep(4000);
		PageBuyPass PB= new PageBuyPass(CreateSession.getAutomationConfiguration().AppiumDriver);
		String Parking =passMapper.getParkingidentifier();
		String PassPromo=passMapper.getpromo();
		String PassName=passMapper.getpassName();
		PB.searchAreaAndBuyPass(Parking,PassPromo,PassName);
		}
		finally
		{   if(CreateSession.getAutomationConfiguration().Platform.equalsIgnoreCase("Android"))
			GB.GetBackToHomeScreen(0);
		}
	}

}
