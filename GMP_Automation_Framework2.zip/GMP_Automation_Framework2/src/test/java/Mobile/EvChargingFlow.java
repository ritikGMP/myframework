package Mobile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.databind.ObjectMapper;

import CommonUtility.CreateSession;
import CommonUtility.demopoc;
import DataDriven.ExcelDriven;
import Mobile.ObjectMapper.LoginMapper;
import Pages.Mobile.EVcharging;
import Pages.Mobile.LaunchQrReader;

import TestNGListeners.ApcoaListeners;
import Utility.TerminalCommand;

public class EvChargingFlow {
	
	@Parameters({ "Environment", "Country","Tenant","Platform" })
	@BeforeClass
	public void initializeDriver(String environment, String country,String tenant, String platform) throws IOException{
		System.out.println( System.getenv("ANDROID_HOME"));
			//	demopoc.runAndroidSimulator();
				demopoc.runIOSSimulator();
		//AutomationConfiguration.Tenant = tenant;
		//AutomationConfiguration.Environment = ennv;
		//AutomationConfiguration.Country = country;
		//AutomationConfiguration.Platform = platform;
		//AutomationConfiguration.extent.setSystemInfo("Tenant",AutomationConfiguration.Tenant);
		//AutomationConfiguration.extent.setSystemInfo("Environment", AutomationConfiguration.Environment);
		//AutomationConfiguration.extent.setSystemInfo("Country", AutomationConfiguration.Country);
		//AutomationConfiguration.extent.setSystemInfo("Platform", AutomationConfiguration.Platform);
		CreateSession cs = new CreateSession();
		cs.readConfigFile("/src/test/java/resources/Mobile/ConfigFiles/"+tenant+".properties",platform);
		CreateSession.getAutomationConfiguration().Country = System.getProperty("country");
		CreateSession.getAutomationConfiguration().Tenant = System.getProperty("tenant");
		CreateSession.getAutomationConfiguration().Environment = System.getProperty("environment");
		CreateSession.getAutomationConfiguration().Platform = System.getProperty("platform");
	}
	/**
	 * method to end the automation
	 *
	 */
	@AfterClass
	public void Teardown(){
		CreateSession.getAutomationConfiguration().AppiumDriver.quit();
	}
	
	@Test
	public void demo() {
		//demopoc.runAndroidSimulator();
	}
	

	@DataProvider
	public LoginMapper[] getLoginData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Login");	
		ObjectMapper mapper = new ObjectMapper();
		LoginMapper []login = new LoginMapper[1];
		login[0] = mapper.readValue(data, LoginMapper.class);
		return login;	
	}

	/**
	 * method to Select country from the select country page
	 * 
	 */
	@Test(priority=1)
	public void selectCountry() throws Exception{
		SmokePnd spnd = new SmokePnd();
		spnd.selectCountry();
	}


	/**
	 * method to enter credentials and check whether user is able to login or not
	 * @param loginMapper contains information of user credentials and username
	 * 
	 */
	@Test(priority=2,dataProvider="getLoginData")
	public void loginAppcoa(LoginMapper loginMapper) throws InterruptedException{
		SmokePnd spnd = new SmokePnd();
		spnd.loginAppcoa(loginMapper);
	}

@Test(priority=14)
	
	public void EVTest() throws IOException, InterruptedException
	{   
	    SoftAssert SA=new SoftAssert();
	    TerminalCommand TC=new TerminalCommand();
	   // SessionCreationPage SC = new SessionCreationPage(CreateSession.getAutomationConfiguration().AppiumDriver);
		LaunchQrReader LR = new LaunchQrReader(CreateSession.getAutomationConfiguration().AppiumDriver);
		EVcharging EV=new EVcharging(CreateSession.getAutomationConfiguration().AppiumDriver);
		
		
		String []ParkingName= new String[]{"Ystadvgen13"};//,"P-Hus_Avenyn","P-hus_Duvan","Ystadvgen13"};//
		String []ParkingAreaCode= new String[]{"2893"};//,"7002","8001","2893"};//,"8001"
		String [][] NameOfChargingStation = new String[][] {};
		
		HashMap<String, String[]> map = new HashMap<String, String[]>();
		  map.put("P-Hus_Avenyn",new String[]{"P01-02","P03-04","P05-06","P07-08","P09-10","P11-12"});//
		  map.put("P-hus_Duvan", new String[] {"P01-02","P03-04","P05-06","P07-08","P09-10","P11-12"});
		  map.put("TurningTorso",new String[] {"P01-02","P03-04","P05-06"} );
		  map.put("Ystadvgen13", new String[] {"P106-107","P108-109","P110-111"});
	 
		for(int i=0;i<ParkingName.length;i++)
		{   
			List<Boolean> SelectFromList=new ArrayList<Boolean>();
			List<Boolean> ScanQrfromAppCamera=new ArrayList<Boolean>();
			List<Boolean> ScanQrfromNativeCamera=new ArrayList<Boolean>();
			
			ApcoaListeners.logInfo("Checking The EV QR FLOW for the Parking -------->"+ParkingName[i]);
			System.out.println("-------------------------------------------------------------------------------------------");
			System.out.println();
			ApcoaListeners.logInfo("getting the parking with Area Code"+ParkingAreaCode[i]+":"+ParkingName[i]);
			EV.GettheParking2(ParkingAreaCode[i]);
			Thread.sleep(2000);
			TC.removeQR();
			Thread.sleep(2000);
			TC.excCommand("QR/EvFlowQR/Stop");
			Thread.sleep(2000);
			SelectFromList=EV.GetEvDataFromSelectList();
			ApcoaListeners.logInfo("Plug Avalability       :"+SelectFromList);
			//System.out.println(SelectFromList);
			
			  
			int length= map.get(ParkingName[i]).length;
			for(int j=0;j<length;j++)
			{   String QRPath="QR/EvFlowQR/"+CreateSession.getAutomationConfiguration().Tenant+"/"+CreateSession.getAutomationConfiguration().Country+"/"+ParkingName[i]+"/"+map.get(ParkingName[i])[j];
			    Thread.sleep(7000);
				TC.removeQR();
				ApcoaListeners.logInfo("QR Folder path  :    "+QRPath);
				TC.excCommand(QRPath);
                EV.getbackparking(ParkingAreaCode[i]);
				List<Boolean> Res=EV.CheckEvChargingQrFlowAppCamera();
				System.out.println(Res.get(0)+":"+Res.get(1));
				ScanQrfromAppCamera.add(Res.get(0));
				boolean temp=Res.get(1);
				
				SA.assertEquals(temp,true);
				SA.assertAll();
			}
			
			
			
			ApcoaListeners.logInfo("EVCharging Flow through Native Camera");
			for(int j=0;j<length;j++)
			{
				String QRPath="QR/EvFlowQR/"+CreateSession.getAutomationConfiguration().Tenant+"/"+CreateSession.getAutomationConfiguration().Country+"/"+ParkingName[i]+"/"+map.get(ParkingName[i])[j];
				     
				    TC.removeQR();
					ApcoaListeners.logInfo("QR Folder path  :    "+QRPath);
					TC.excCommand(QRPath);
					Thread.sleep(5000);
					LR.launchQrReader();
					TC.removeQR();
				    TC.excCommand("QR/EvFlowQR/Stop");
					List<Boolean> Res=EV.CheckEvChargingQrFlowNativeCamera();
					ScanQrfromNativeCamera.add(Res.get(0));
					boolean temp=Res.get(1);
					LR.KillQrScanner();
					SA.assertEquals(temp,true);
					
					Thread.sleep(15000);
				    SA.assertAll();
					
			}
			
			
			
			System.out.println(SelectFromList);
			System.out.println(ScanQrfromAppCamera);
			System.out.println(ScanQrfromNativeCamera);
			
			SA.assertEquals(SelectFromList,ScanQrfromAppCamera);
			SA.assertEquals(ScanQrfromAppCamera, ScanQrfromNativeCamera);
			SA.assertAll();
			
			}
		
	}

}
