package Mobile;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;


import CommonUtility.CreateSession;
import CommonUtility.demopoc;
import DataDriven.ExcelDriven;
import Mobile.ObjectMapper.LoginMapper;
import Mobile.ObjectMapper.ParkingMapper;
import Pages.Mobile.InvoiceCheck;



public class Invoice {
	
	@Parameters({ "Environment", "Country","Tenant","Platform" })
	@BeforeClass
	public void initializeDriver(String environment, String country,String tenant, String platform) throws IOException{
		System.out.println( System.getenv("ANDROID_HOME"));
			//	demopoc.runAndroidSimulator();
				demopoc.runIOSSimulator();
		//AutomationConfiguration.Tenant = tenant;
		//AutomationConfiguration.Environment = ennv;
		//AutomationConfiguration.Country = country;
		//AutomationConfiguration.Platform = platform;
		//AutomationConfiguration.extent.setSystemInfo("Tenant",AutomationConfiguration.Tenant);
		//AutomationConfiguration.extent.setSystemInfo("Environment", AutomationConfiguration.Environment);
		//AutomationConfiguration.extent.setSystemInfo("Country", AutomationConfiguration.Country);
		//AutomationConfiguration.extent.setSystemInfo("Platform", AutomationConfiguration.Platform);
		CreateSession cs = new CreateSession();
		cs.readConfigFile("/src/test/java/resources/Mobile/ConfigFiles/"+tenant+".properties",platform);
		CreateSession.getAutomationConfiguration().Country = System.getProperty("country");
		CreateSession.getAutomationConfiguration().Tenant = System.getProperty("tenant");
		CreateSession.getAutomationConfiguration().Environment = System.getProperty("environment");
		CreateSession.getAutomationConfiguration().Platform = System.getProperty("platform");
	}
	/**
	 * method to end the automation
	 *
	 */
	@AfterClass
	public void Teardown(){
		CreateSession.getAutomationConfiguration().AppiumDriver.quit();
	}
	
	@Test
	public void demo() {
		//demopoc.runAndroidSimulator();
	}
	

	@DataProvider
	public LoginMapper[] getLoginData() throws Exception{
		System.out.println(CreateSession.getAutomationConfiguration().Country+"   "+CreateSession.getAutomationConfiguration().Tenant+ 
				"  "+CreateSession.getAutomationConfiguration().Environment);
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Login");	
		ObjectMapper mapper = new ObjectMapper();
		LoginMapper []login = new LoginMapper[1];
		login[0] = mapper.readValue(data, LoginMapper.class);
		return login;	
	}
	
	@DataProvider
	public ParkingMapper[] getParkingData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Session");		
		ObjectMapper mapper = new ObjectMapper();
		ParkingMapper []parking = new ParkingMapper[1];
		parking[0] = mapper.readValue(data, ParkingMapper.class);
		return parking;	
	}

	/**
	 * method to Select country from the select country page
	 * 
	 */
	@Test(priority=1)
	public void selectCountry() throws Exception{
		SmokePnd spnd = new SmokePnd();
		spnd.selectCountry();
	}


	/**
	 * method to enter credentials and check whether user is able to login or not
	 * @param loginMapper contains information of user credentials and username
	 * 
	 */
	@Test(priority=2,dataProvider="getLoginData")
	public void loginAppcoa(LoginMapper loginMapper) throws InterruptedException{
		SmokePnd spnd = new SmokePnd();
		spnd.loginAppcoa(loginMapper);
	}
	
	@Test(priority=3,dataProvider = "getParkingData")
	public void verifyInvoicePDF(ParkingMapper parkingMapper) throws InterruptedException, IOException
	{
		//SessionCreationPage SC = new SessionCreationPage(AutomationConfiguration.AppiumDriver);
		InvoiceCheck IV=new InvoiceCheck(CreateSession.getAutomationConfiguration().AppiumDriver);
		IV.navigateToDownloadPDF(parkingMapper);
		//VerifyPDF VP=new VerifyPDF();
		//VP.SendPDF("AT46303718006");
	}


}
