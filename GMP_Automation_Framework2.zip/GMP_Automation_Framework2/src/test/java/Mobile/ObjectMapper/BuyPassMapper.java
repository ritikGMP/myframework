package Mobile.ObjectMapper;
public class BuyPassMapper {
    
     private String parkingidentifier;
     private String promo;
     private String passName;
     
     public String getpassName() {
		return passName;
	}

	public void setpassName(String passName) {
		this.passName = passName;
	}

	public BuyPassMapper() {
     }
     
     public String getParkingidentifier() {
         return this.parkingidentifier;           // {"parkingidentifier":"Raxstra","promo":"REGTESTATPASS"}
     }
     
     public void setParkingidentifier(String parkingidentifier) {
         this.parkingidentifier = parkingidentifier;
     }
     
     public String getpromo() {
         return this.promo;
     }
     
     public void setpromo(String promo)
     {
         this.promo=promo;
     }
     
     @Override
     public String toString() {
         return  "BuyPassMapper{" +
                 "parkingidentifier='" + parkingidentifier + '\'' +
                 ", promo='" + promo + '\'' +  
                 ", passName='" + passName + '\'' + 
                 '}';
     }
     
}
