package Mobile;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.databind.ObjectMapper;

import CommonUtility.CreateSession;
import CommonUtility.demopoc;
import DataDriven.ExcelDriven;
import Mobile.ObjectMapper.InAppMarketPlaceMapper;
import Mobile.ObjectMapper.LoginMapper;
import Mobile.ObjectMapper.VehicleMapper;
import Pages.Mobile.PageHomeApcoa;
import Pages.Mobile.PageLogin;
import Pages.Mobile.PageMapScreen;
import Pages.Mobile.PageSelectCountry;

public class Tpay {
	
	

	@Parameters({ "Environment", "Country","Tenant","Platform" })
	@BeforeClass
	public void initializeDriver(String ennv, String country,String tenant, String platform) throws IOException{
		System.out.println( System.getenv("ANDROID_HOME"));
			//	demopoc.runAndroidSimulator();
				demopoc.runIOSSimulator();
		//AutomationConfiguration.Tenant = tenant;
		//AutomationConfiguration.Environment = ennv;
		//AutomationConfiguration.Country = country;
		//AutomationConfiguration.Platform = platform;
		//AutomationConfiguration.extent.setSystemInfo("Tenant",AutomationConfiguration.Tenant);
		//AutomationConfiguration.extent.setSystemInfo("Environment", AutomationConfiguration.Environment);
		//AutomationConfiguration.extent.setSystemInfo("Country", AutomationConfiguration.Country);
		//AutomationConfiguration.extent.setSystemInfo("Platform", AutomationConfiguration.Platform);
		CreateSession cs = new CreateSession();
		cs.readConfigFile("/src/test/java/resources/Mobile/ConfigFiles/"+tenant+".properties",platform);
		CreateSession.getAutomationConfiguration().Country = country;
		CreateSession.getAutomationConfiguration().Tenant = tenant;
		CreateSession.getAutomationConfiguration().Environment = ennv;
		CreateSession.getAutomationConfiguration().Platform = platform;
	}
	/**
	 * method to end the automation
	 *
	 */
	@AfterClass
	public void Teardown(){
		CreateSession.getAutomationConfiguration().AppiumDriver.quit();
	}
	
	
	@DataProvider
	public LoginMapper[] getLoginData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Login");	
		ObjectMapper mapper = new ObjectMapper();
		LoginMapper []login = new LoginMapper[1];
		login[0] = mapper.readValue(data, LoginMapper.class);

		return login;	
	}

	/**
	 * method to give data for vehicle addition and deletion
	 * 
	 * @return object that contains the vehicle lpr data
	 */
	@DataProvider
	public VehicleMapper[] getVehicleData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Add Vehicle");
		ObjectMapper mapper = new ObjectMapper();
		VehicleMapper []vehicle = new VehicleMapper[1];
		vehicle[0] = mapper.readValue(data, VehicleMapper.class);

		return vehicle;	
	}

	/**
	 * method to data for making session and extending session
	 * 
	 * @return Object that contains information of parking and other related stuffs.
	 */
	@DataProvider
	public InAppMarketPlaceMapper[] getInAppParkingData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"InAppMarketPlace");		
		ObjectMapper mapper = new ObjectMapper();
		InAppMarketPlaceMapper []parking = new InAppMarketPlaceMapper[1];
		parking[0] = mapper.readValue(data, InAppMarketPlaceMapper.class);
		return parking;	
	}
	
	
	@Test(priority=1)
	public void selectCountry() throws Exception{
		System.out.println(CreateSession.getAutomationConfiguration().AppiumDriver.getPageSource());
		Thread.sleep(2000);
		PageSelectCountry selectcountry = new PageSelectCountry(CreateSession.getAutomationConfiguration().AppiumDriver);
		SoftAssert softAssert = new SoftAssert();
		if(CreateSession.getAutomationConfiguration().Tenant.equalsIgnoreCase("Apcoa") || CreateSession.getAutomationConfiguration().Tenant.equalsIgnoreCase("GMP")) {
			//System.out.println(CreateSession.getAutomationConfiguration().AppiumDriver.findElement(By.xpath("//*[contains(@resource-id,':id/text')]")).getText());
			selectcountry.selectCountryClick();
			Thread.sleep(2000);
			selectcountry.selectCountry(CreateSession.getAutomationConfiguration().Country);
			softAssert.assertEquals(CreateSession.getAutomationConfiguration().Country.toUpperCase(), selectcountry.CountrySelected.toUpperCase(),"Country not selected" );		
		}
		Thread.sleep(3000);
		selectcountry.btnLoginClick();
		softAssert.assertAll();
	}


	
	
	/**
	 * method to enter credentials and check whether user is able to login or not
	 * @param loginMapper contains information of user credentials and username
	 * 
	 */
	@Test(priority=2,dataProvider="getLoginData")
	public void loginAppcoa(LoginMapper loginMapper) throws InterruptedException{
		PageLogin login = new PageLogin(CreateSession.getAutomationConfiguration().AppiumDriver);
		Thread.sleep(3000);
		login.enterCredentials(loginMapper.getEmail(), loginMapper.getPassword());
		Thread.sleep(2000);
		login.clickContinue();

		PageHomeApcoa home = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		home.acceptPushNotification();
		home.checkUserName();
		home.cancelActivatePopUp();
		home.cancelQuestionPopUp();

		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(loginMapper.getUsername().toUpperCase(),home.Username.toUpperCase() );
		softAssert.assertAll();	

	}

	
	@Test(priority = 5, dataProvider = "getInAppParkingData")
	public void searchParking(InAppMarketPlaceMapper parkingMapper) throws InterruptedException {
		
		
		
		System.out.println("heelo in gther");
		String parkingName = parkingMapper.getParkingidentifier();
		String fullParkingName = parkingMapper.getParkingname();
		SoftAssert softAssert = new SoftAssert();

		PageMapScreen pms = new PageMapScreen(CreateSession.getAutomationConfiguration().AppiumDriver);
		pms.FullParkingName = fullParkingName;
		pms.GettheParking(parkingName);

		softAssert.assertEquals(fullParkingName, pms.ActualParkingName, "Parking Name Not Found.");
		softAssert.assertAll();
	
	} 
	
	@Test(priority=4)
	public void AddPaymentCard()
	{
		
	}
	

}
