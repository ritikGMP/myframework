package Mobile;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.databind.ObjectMapper;

import CommonUtility.CreateSession;
import DataDriven.ExcelDriven;
import Mobile.ObjectMapper.LoginMapper;
import Mobile.ObjectMapper.ParkingMapper;
import Mobile.ObjectMapper.VehicleMapper;
import Pages.Mobile.PageHomeApcoa;
import Pages.Mobile.PageLogin;
import Pages.Mobile.PageSelectCountry;
import Pages.Mobile.PageSetting;

public class WhiteLabelling {
	
	
	WebDriver driver;
	
	@Parameters({ "Environment", "Country","Tenant","Platform" })
	@BeforeClass
	public void initializeDriver(String ennv, String country,String tenant, String platform) throws IOException{
		//AutomationConfiguration.Tenant = tenant;
		//AutomationConfiguration.Environment = ennv;
		//AutomationConfiguration.Country = country;
		//AutomationConfiguration.Platform = platform;
		//AutomationConfiguration.extent.setSystemInfo("Tenant",AutomationConfiguration.Tenant);
		//AutomationConfiguration.extent.setSystemInfo("Environment", AutomationConfiguration.Environment);
		//AutomationConfiguration.extent.setSystemInfo("Country", AutomationConfiguration.Country);
		//AutomationConfiguration.extent.setSystemInfo("Platform", AutomationConfiguration.Platform);
		CreateSession cs = new CreateSession();
		cs.readConfigFile("/src/test/java/resources/Mobile/ConfigFiles/"+tenant+".properties",platform);
		CreateSession.getAutomationConfiguration().Country = country;
		CreateSession.getAutomationConfiguration().Tenant = tenant;
		CreateSession.getAutomationConfiguration().Environment = ennv;
		CreateSession.getAutomationConfiguration().Platform = platform;
	}

	/**
	 * method to end the automation
	 *
	 */
	@AfterClass
	public void Teardown()
	{
		CreateSession.getAutomationConfiguration().AppiumDriver.quit();
	}

	/**
	 * method to give data for login
	 *
	 * @return object that contains the user credentials
	 */
	@DataProvider
	public LoginMapper[] getLoginData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Login");	
		ObjectMapper mapper = new ObjectMapper();
		LoginMapper []login = new LoginMapper[1];
		login[0] = mapper.readValue(data, LoginMapper.class);

		return login;	
	}

	/**
	 * method to give data for vehicle addition and deletion
	 * 
	 * @return object that contains the vehicle lpr data
	 */
	@DataProvider
	public VehicleMapper[] getVehicleData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Add Vehicle");
		ObjectMapper mapper = new ObjectMapper();
		VehicleMapper []vehicle = new VehicleMapper[1];
		vehicle[0] = mapper.readValue(data, VehicleMapper.class);

		return vehicle;	
	}

	/**
	 * method to data for making session and extending session
	 * 
	 * @return Object that contains information of parking and other related stuffs.
	 */
	@DataProvider
	public ParkingMapper[] getParkingData() throws Exception{
		String excelfilepath = System.getProperty("user.dir") + "/src/test/java/resources/Mobile/Dataset/"+CreateSession.getAutomationConfiguration().Tenant+"Dataset.xlsx";
		ExcelDriven.readExcelFile(excelfilepath, CreateSession.getAutomationConfiguration().Environment);
		String data = ExcelDriven.readDataRowandColumn(CreateSession.getAutomationConfiguration().Environment,CreateSession.getAutomationConfiguration().Country,"Session");		
		ObjectMapper mapper = new ObjectMapper();
		ParkingMapper []parking = new ParkingMapper[1];
		parking[0] = mapper.readValue(data, ParkingMapper.class);
		return parking;	
	}

	@Test(priority=1)
	public void selectCountry() throws Exception{
		System.out.println(CreateSession.getAutomationConfiguration().AppiumDriver.getPageSource());
		Thread.sleep(2000);
		PageSelectCountry selectcountry = new PageSelectCountry(CreateSession.getAutomationConfiguration().AppiumDriver);
		SoftAssert softAssert = new SoftAssert();
		if(CreateSession.getAutomationConfiguration().Tenant.equalsIgnoreCase("Apcoa") || CreateSession.getAutomationConfiguration().Tenant.equalsIgnoreCase("GMP")) {
			//System.out.println(CreateSession.getAutomationConfiguration().AppiumDriver.findElement(By.xpath("//*[contains(@resource-id,':id/text')]")).getText());
			selectcountry.selectCountryClick();
			Thread.sleep(2000);
			selectcountry.selectCountry(CreateSession.getAutomationConfiguration().Country);
			softAssert.assertEquals(CreateSession.getAutomationConfiguration().Country.toUpperCase(), selectcountry.CountrySelected.toUpperCase(),"Country not selected" );		
		}
		Thread.sleep(3000);
		selectcountry.btnLoginClick();
		softAssert.assertAll();
	}


	
	
	/**
	 * method to enter credentials and check whether user is able to login or not
	 * @param loginMapper contains information of user credentials and username
	 * 
	 */
	@Test(priority=2,dataProvider="getLoginData")
	public void loginAppcoa(LoginMapper loginMapper) throws InterruptedException{
		PageLogin login = new PageLogin(CreateSession.getAutomationConfiguration().AppiumDriver);
		Thread.sleep(3000);
		login.enterCredentials(loginMapper.getEmail(), loginMapper.getPassword());
		Thread.sleep(2000);
		login.clickContinue();

		PageHomeApcoa home = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		home.acceptPushNotification();
		home.checkUserName();
		home.cancelActivatePopUp();
		home.cancelQuestionPopUp();

		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(loginMapper.getUsername().toUpperCase(),home.Username.toUpperCase() );
		softAssert.assertAll();	

	}
	
	@Test(priority=3)
	public void CheckSetting() throws InterruptedException
	 { SoftAssert SA=new SoftAssert();
		PageSetting PS=new PageSetting(CreateSession.getAutomationConfiguration().AppiumDriver);
		PS.NavigateToLegalsInSetting();
	 boolean termandcondition=	PS.CheckTermAndCond();
	 boolean PrivacyPolicy=	PS.CheckPrivacyPolicy();
	 boolean Imprint=   PS.CheckImprint();
	 SA.assertEquals(PrivacyPolicy,true);
	 SA.assertEquals(termandcondition,true);
	 SA.assertEquals(Imprint,true);
	 
	SA.assertAll();
		
	}
	@Test(priority=4)
	public void checkHelpAndSupport() throws InterruptedException
	{
		SoftAssert SA=new SoftAssert();
		PageSetting PS=new PageSetting(CreateSession.getAutomationConfiguration().AppiumDriver);
		PS.NavigateToLegalsInSetting();
		PS.CheckHowWorks();
		boolean contactcustomersupport= PS.checkContactCustomerSupport();
		boolean messagecustomersupport=PS.MessageCustomerSupport();
		
		SA.assertEquals(contactcustomersupport, true);
		SA.assertEquals(messagecustomersupport, true);
		SA.assertAll();
		
	}

}
