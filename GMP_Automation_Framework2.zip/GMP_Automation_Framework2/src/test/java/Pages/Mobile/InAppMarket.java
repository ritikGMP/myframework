package Pages.Mobile;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import CommonUtility.CreateSession;
import CommonUtility.GenericMethods;
import TestNGListeners.ApcoaListeners;

import Utility.ImageComparison;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class InAppMarket {

	WebDriver driver;
	
	
	String GuestName="Ritik Sharma";
	String PhoneNo="73514592";
	String HotelGuestStatus="TRUE";
	String GuestRoomNo="205";
	String StaffJobTitle="DEF";
	String Fuelprice="$40.00";
	String ValetServiceCheckNo="4123";
	String ParkingLocation="Nilay Test";
	String VehicleModel="classic";
	String VehicleColor="RED";
	String ItemName="Fruits";
	String ItemQuant="10";
	String MultiPurposeDetail="Hello World";
	
	public InAppMarket(WebDriver appiumDriver) {
		this.driver = appiumDriver;
		PageFactory.initElements(new AppiumFieldDecorator(appiumDriver), this);

	}

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'id/tv_header')]")
	WebElement TimeSlots;
	@AndroidFindBy(xpath = "(//android.widget.TextView[contains(@resource-id,'id/tv_time_slot')])[1]")
	WebElement AvailableSlot;
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Confirm')]")
	WebElement Confirm;
	@AndroidFindBy(xpath = "(//android.widget.TextView[contains(@resource-id,'id/tv_pay')])")
	WebElement ElementPay;
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'id/ll_parent')])")
	WebElement TimeSlot;
	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@resource-id,'d/et_item_name')]")
	WebElement AddItem;
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'id/btn_button_bottom')])")
	WebElement OkButton;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'id/text')]")
	WebElement SelectCountryBtn;
	
	
	
	@AndroidFindBy(xpath = "(//*[contains(@resource-id,'id/cl_vas_active')])")
	WebElement Order;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[contains(@resource-id,'id/tv_service_name')])[1]")
	WebElement ServiceName;
	
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_close') or contains(@resource-id,':id/tv_negative_action_button') or contains(@resource-id,':id/iv_back')]")
	private WebElement close;
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/ivNotification')]")
	private WebElement BtnNotification;
	

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/button1')]")
	private WebElement okBtn;
	@AndroidFindBy(xpath = "(//android.widget.CheckedTextView[contains(@resource-id,'id/text1')])[2]")
	private WebElement FuelPrice;

	public boolean TakeScreenShotAndCompare(WebElement element) throws InterruptedException {
		ImageComparison IC = new ImageComparison();
		String p1 = GenericMethods.elementScreenshot(element);
		// String
		// p1=SH.elementScreenshot(CreateSession.getAutomationConfiguration().AppiumDriver,element);
		String p2 = "/home/ritik/eclipse-workspace/GMP_HybridAutomationFramework-masterfinalProduction2/screenshots/6b467ab2-0af5-4532-ab58-236213185cb3.png";
		double diff = IC.comapareImages(p1, p2, false);
		if (diff >= 0.0 && diff <= 0.5) {
			ApcoaListeners.logInfo("Images Are Same");
			Thread.sleep(4000);
			removeScreenshot(p1);
			return true;

		} else {
			ApcoaListeners.logInfo("Images Are Different");
			Thread.sleep(4000);
			removeScreenshot(p1);
			return false;
		}

	}

	public void removeScreenshot(String path) {
		String command = "rm " + path;

		try {
			Process p = Runtime.getRuntime().exec(command);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		ApcoaListeners.logInfo("ScreenShot Deleted");
	}

	By ServiceAvailable = By.xpath("//android.widget.TextView[contains(@resource-id,'id/tv_service_name')]");

	public ArrayList<WebElement> checkServiceAvailable() {
		ArrayList<WebElement> service = (ArrayList<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver
				.findElements(ServiceAvailable);
		ApcoaListeners.logInfo("Number of Service Available ------>" + service.size());

		return service;
	}

	
	public void checkAutoRefueling() throws InterruptedException {
		
		
		CheckTheTimeSlot();
		CommonUtility.GenericMethods.explicitWait(driver, AvailableSlot, 30);
		AvailableSlot.click();
		CommonUtility.GenericMethods.explicitWait(driver, Confirm, 30);
		Confirm.click();
		Thread.sleep(4000);
		System.out.println("entering the data ");
		DataEntry();

	}
	
	By DataFeild = By.xpath("//*[contains(@resource-id,'id/textView') or contains(@resource-id,'id/et_text') or contains(@resource-id,'id/text1') or  contains(@resource-id,'id/tv_add')]");
	By DataFeildName = By.xpath("//android.widget.TextView[contains(@resource-id,'id/tv_header')]");
     
	public void DataEntry() throws InterruptedException
	{   ArrayList<String> FeildName = new ArrayList<String>();
		ArrayList<WebElement> datafeildname = (ArrayList<WebElement>) CreateSession
				.getAutomationConfiguration().AppiumDriver.findElements(DataFeildName);
		ArrayList<WebElement> datafeild = (ArrayList<WebElement>) CreateSession
				.getAutomationConfiguration().AppiumDriver.findElements(DataFeild);

		int loopcontroller = Math.min(datafeildname.size(), datafeild.size());
		int k;
		for (int i = 0; i < loopcontroller; i++) {
			if (datafeildname.size() == datafeild.size()) {
				k = i + 1;
				loopcontroller = datafeildname.size() - 1;

			} else {
				if (datafeildname.size() == 4 && datafeild.size() == 5)
					k = i + 1;
				else
					k = i;
			}

			if (!FeildName.contains(datafeildname.get(i).getText())) {
				FeildName.add(datafeildname.get(i).getText());
				if (datafeildname.get(i).getText().equalsIgnoreCase("Guest Name"))
					{ApcoaListeners.logInfo("entering the Guest name");
					datafeild.get(k).sendKeys(GuestName);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Phone No"))
					{ApcoaListeners.logInfo("entering the Phone No.");
					datafeild.get(k).sendKeys(PhoneNo);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Hotel Guest Status"))
					{ApcoaListeners.logInfo("entering the Hotel Guest Status");
					//datafeild.get(k).sendKeys(HotelGuestStatus);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Guest Room No."))
					{ApcoaListeners.logInfo("entering the Guest Room no.");
					datafeild.get(k).sendKeys(GuestRoomNo);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Staff Job Title"))
					{ApcoaListeners.logInfo("entering the Staff job title");
					datafeild.get(k).sendKeys(StaffJobTitle);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Booking Datetime")) {
					
					ApcoaListeners.logInfo("entering Booking DATETIME");
					datafeild.get(k).click();
					CommonUtility.GenericMethods.explicitWait(driver, okBtn, 5);
					okBtn.click();
					CommonUtility.GenericMethods.explicitWait(driver, okBtn, 5);
					okBtn.click();
				}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Booking Date")) {
					ApcoaListeners.logInfo("entering the Booking Date");
					datafeild.get(k).click();
					CommonUtility.GenericMethods.explicitWait(driver, okBtn, 5);
					okBtn.click();
					CommonUtility.GenericMethods.explicitWait(driver, okBtn, 5);
					okBtn.click();
				}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Fuel Price")) {
					ApcoaListeners.logInfo("entering the Fuel Price");
					datafeild.get(k).click();
					CommonUtility.GenericMethods.explicitWait(driver, FuelPrice, 5);
					FuelPrice.click();

				} else if (datafeildname.get(i).getText().equalsIgnoreCase("Valet Service Check No"))
					{ApcoaListeners.logInfo("entering the Valet Service Check No.");
					datafeild.get(k).sendKeys(ValetServiceCheckNo);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Parking Location"))
					{ApcoaListeners.logInfo("entering the parking Location");
					datafeild.get(k).sendKeys(ParkingLocation);
					}

				else if (datafeildname.get(i).getText().equalsIgnoreCase("Vehicle Model"))
					{ApcoaListeners.logInfo("entering the Vehicle Model");
					datafeild.get(k).sendKeys(VehicleModel);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Vehicle Color"))
					{ApcoaListeners.logInfo("entering the Vehicle color");
					datafeild.get(k).sendKeys(VehicleColor);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Item Name"))
					{ApcoaListeners.logInfo("entering the Item name");
					datafeild.get(k).sendKeys(ItemName);
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Multi Purpose Detail"))
					{datafeild.get(k).sendKeys(MultiPurposeDetail);
					break;
					}
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Grocery Detail"))
					{ datafeild.get(k).click();
					  CommonUtility.GenericMethods.explicitWait(driver, AddItem, 5);
					  AddItem.sendKeys(ItemName);
					  ((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
						Thread.sleep(3000);
					  }
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Item Quantity"))
					{datafeild.get(k).sendKeys(ItemQuant);
					 break; 
					}
				
				else if (datafeildname.get(i).getText().equalsIgnoreCase("Vehicle License Plate No.")) {
					System.out.println("breaking");
					break;
				}
				

			}
			if (i == loopcontroller - 1) {
				System.out.println("taking webelemt");
				TouchAction action = new TouchAction(CreateSession.getAutomationConfiguration().AppiumDriver);
				action.press(PointOption.point(533, 1859)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
						.moveTo(PointOption.point(512, 1513)).release().perform();
				i = 0;
				datafeildname = (ArrayList<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver.findElements(DataFeildName);
				datafeild = (ArrayList<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver.findElements(DataFeild);
			}
		}
		System.out.println("click on confirm");
		CommonUtility.GenericMethods.explicitWait(driver, Confirm, 5);
		Confirm.click();
	}
	
	By Feild = By.xpath("//android.widget.TextView");

	public void ReviewOrder() throws InterruptedException
	{   System.out.println("Reviewing the order");
		Thread.sleep(6000); 
		SoftAssert SA=new SoftAssert();
		ArrayList<WebElement> datafeild = (ArrayList<WebElement>) CreateSession
				.getAutomationConfiguration().AppiumDriver.findElements(Feild);
		
		for(int i=2;i<datafeild.size();i=i+2)
		{
		  if(datafeild.get(i).getText().equals("Guest Name"))
		  {System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText());
			  SA.assertEquals(datafeild.get(i+1).getText(), GuestName);
		  }
		  else if(datafeild.get(i).getText().equals("Phone No"))
			  {System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			  SA.assertEquals(datafeild.get(i+1).getText(), PhoneNo);}
		  else if(datafeild.get(i).getText().equals("Hotel Guest Status"))
		  { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText());
			  SA.assertEquals(datafeild.get(i+1).getText(), HotelGuestStatus);}
		  else if(datafeild.get(i).getText().equals("Guest Room No."))
		  { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			  SA.assertEquals(datafeild.get(i+1).getText(), GuestRoomNo);}
		  else if(datafeild.get(i).getText().equals("Guest Room No."))
		  {  System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText());
			  SA.assertEquals(datafeild.get(i+1).getText(), GuestRoomNo);}
		   else if(datafeild.get(i).getText().equals("Staff Job Title"))
		   {  System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			   SA.assertEquals(datafeild.get(i+1).getText(), StaffJobTitle);}
		   else if(datafeild.get(i).getText().equals("Fuel Price"))
		   { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			   SA.assertEquals(datafeild.get(i+1).getText(),Fuelprice);}
		   else if(datafeild.get(i).getText().equals("Valet Service Check No"))
		   { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			   SA.assertEquals(datafeild.get(i+1).getText(),ValetServiceCheckNo);}
		   else if(datafeild.get(i).getText().equals("Item Name"))
		   { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			   SA.assertEquals(datafeild.get(i+1).getText(),ItemName);}
		   else if(datafeild.get(i).getText().equals("Multi Purpose Detail"))
		   { System.out.println(datafeild.get(i).getText()+"--------->"+datafeild.get(i+1).getText()); 
			   SA.assertEquals(datafeild.get(i+1).getText(),MultiPurposeDetail);}
		  
		}
		
		SA.assertAll();
		CommonUtility.GenericMethods.explicitWait(driver, ElementPay, 5);
		ElementPay.click();
		CommonUtility.GenericMethods.explicitWait(driver, OkButton, 10);
		OkButton.click();
		Thread.sleep(5000);
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
         Thread.sleep(2000);
		
	}
	
	public Boolean CheckCreatedOrder(String Service)
	{   
		CommonUtility.GenericMethods.explicitWait(driver, Order, 10);
		Order.click();
		CommonUtility.GenericMethods.explicitWait(driver, ServiceName, 5);
		if(ServiceName.getText().equals(Service))
		{
			return true;
		}
		else
			return false;
		
	}
	
	
	
	 
	
	
	

	By TimeSlotAvailable = By.xpath("//android.widget.TextView[contains(@resource-id,'id/tv_header')]");

	public void CheckTheTimeSlot() throws InterruptedException {
		ArrayList<String> Date = new ArrayList<String>();
		ArrayList<WebElement> slots = (ArrayList<WebElement>) this.driver.findElements(TimeSlotAvailable);
		int count = 0;
		for (int i = 0; i < slots.size(); i++) {
			System.out.println(slots.size());
			System.out.println(slots.get(i).getText());
			if (!Date.contains(slots.get(i).getText())) {
				System.out.println("adding to date");
				Date.add(slots.get(i).getText());
				System.out.println(slots.get(i).getText());
			}

			if (i == 3) {
				ApcoaListeners.logInfo("Swapping Up.......");
				TouchAction action = new TouchAction(CreateSession.getAutomationConfiguration().AppiumDriver);
				action.press(PointOption.point(464, 1727)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
						.moveTo(PointOption.point(492, 391)).release().perform();
				i = 0;
				count++;
				if (count == 2)
					break;
				Thread.sleep(5000);
				slots = (ArrayList<WebElement>) this.driver.findElements(TimeSlotAvailable);
			}
		}

		ApcoaListeners.logInfo("Date Available........>");
		for (int i = 0; i < Date.size(); i++) {

			ApcoaListeners.logInfo(Date.get(i));

		}

	}
	
	
	public void checkGroceryShopping() throws InterruptedException
	{
		ApcoaListeners.logInfo("Selecting the Grocery Store");
		CommonUtility.GenericMethods.explicitWait(driver, Confirm, 15);
		Confirm.click();
		ApcoaListeners.logInfo("Selecting the Time Slot");
		CommonUtility.GenericMethods.explicitWait(driver, TimeSlot, 15);
		TimeSlot.click();
		CommonUtility.GenericMethods.explicitWait(driver, Confirm, 15);
		Confirm.click();
		Thread.sleep(5000);
		DataEntry();
		Thread.sleep(8000);
		
	}
	
	public void checkErrandsServices() throws InterruptedException
	{
		ApcoaListeners.logInfo("Selecting the ErrandsServices");
		CheckTheTimeSlot();
		CommonUtility.GenericMethods.explicitWait(driver, AvailableSlot, 30);
		AvailableSlot.click();
		CommonUtility.GenericMethods.explicitWait(driver, Confirm, 30);
		Confirm.click();
		Thread.sleep(4000);
		DataEntry();
		Thread.sleep(8000);
		
		
	}
	
	public void GetBackToHomeScreen(int i) throws InterruptedException
	{  
		
		try {
	    	CommonUtility.GenericMethods.explicitWait(driver,close,5);
		  close.click();
	       }
	catch(Exception e)
	{}
		
	   if(checknotificationbtn()||i==10)
	   {   ApcoaListeners.logInfo("Already at home screen");
		   return;
	   }
	   else
	   {  i++;
		   ApcoaListeners.logInfo("Not At home Screen");
	      ApcoaListeners.logInfo("pressing the back button");
		   ((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	        Thread.sleep(3000);
		   GetBackToHomeScreen(i);
	   }
	
	
	}
	public boolean checknotificationbtn()
	{
		try {
			 if(BtnNotification.isDisplayed())
			   {   ApcoaListeners.logInfo("Already at home screen");
				   return true;
			   }
			 return false;
		}
		catch(Exception e) {
			return false;
		}
	}

}
