package Pages.Mobile;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import CommonUtility.CreateSession;
import Mobile.ObjectMapper.ParkingMapper;
import TestNGListeners.ApcoaListeners;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class InvoiceCheck {
	
	
	WebDriver driver;
	TouchAction action;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/androidx.drawerlayout.widget.DrawerLayout/android.view.ViewGroup/android.widget.LinearLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.ImageView[1]")
	private WebElement btnMenu;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_sessions')]")
	private WebElement MenuMySessions;
	@AndroidFindBy(xpath="//android.widget.LinearLayout[@content-desc='Expired']")
	private WebElement MySessionsGotoExpiredSessionsApcoa;
	
	@AndroidFindBy(xpath="//android.widget.LinearLayout[@content-desc=\"Past\"]/android.widget.TextView")//here
	private WebElement GMPMySessionsGotoExpiredSessions;


	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_session_id')]")
	private WebElement MySessionsSessionID;

	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_cost')]")
	private WebElement MySessionsTotalCost;

	@AndroidFindBy(xpath="//android.widget.LinearLayout[@content-desc=\"Past\"]/android.widget.TextView")
	private WebElement MySessionsGotoExpiredSessions;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_name')]")
	private WebElement ActiveParking;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_access_identifier')]")
	private WebElement VehicleNumber;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_payment_card_number')]")
	private WebElement PaymentCard;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/ivNotification')]")
	private WebElement BtnNotification;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout")
	private WebElement Screen;
	
	
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'DOWNLOAD INVOICE')]")
	private WebElement DownloadInvoice;
	@AndroidFindBy(xpath="(//android.widget.ImageView[@content-desc=\"Image\"])[1]")
	private WebElement DownloadPDF;
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/dismiss_text')]")
	private WebElement closeallnotification;
	@AndroidFindBy(xpath="(//android.widget.TextView)[5]")
	private WebElement PDFName;
	
	

	public InvoiceCheck(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator (driver), this);
		action=new TouchAction((PerformsTouchActions) driver);
	}
	
	public void navigateToDownloadPDF(ParkingMapper parkingMapper) throws InterruptedException, IOException
	{   
		SoftAssert SA=new SoftAssert();
		String SessionID,TotalCost,PDFNumber,ParkingName,VehicleNum,Paymentcard=null,Currency,Username;
	    
		ApcoaListeners.logInfo("Going to click on hamburger menu");
		CommonUtility.GenericMethods.explicitWait(driver,btnMenu,30);
		btnMenu.click();
		ApcoaListeners.logInfo("Going to click on MySession menu");
		CommonUtility.GenericMethods.explicitWait(driver,MenuMySessions,30);
		MenuMySessions.click();
		Thread.sleep(3000);
		ApcoaListeners.logInfo("Going to click on Expired Session menu");
		try {
		CommonUtility.GenericMethods.explicitWait(driver,MySessionsGotoExpiredSessionsApcoa,10);
		MySessionsGotoExpiredSessionsApcoa.click();
		}
		catch(Exception e)
		{
			CommonUtility.GenericMethods.explicitWait(driver,GMPMySessionsGotoExpiredSessions,10);
			GMPMySessionsGotoExpiredSessions.click();
		}
		
		SessionID=MySessionsSessionID.getText();
		
		
     	System.out.println(MySessionsTotalCost.getText());
     	if(!parkingMapper.getCurrency().equals("$"))
		TotalCost=MySessionsTotalCost.getText().split(parkingMapper.getCurrency())[1];
     	else
     	TotalCost=MySessionsTotalCost.getText().split("\\$")[1];
		
		ParkingName=ActiveParking.getText();
		VehicleNum=VehicleNumber.getText();
		try {
		if(PaymentCard.isDisplayed())
	    Paymentcard=PaymentCard.getText();
		}
		catch(Exception e)
		{
		}
		
		
		
		
		if(parkingMapper.getCurrency().equals("PLN"))
			Currency="zł";
		else if(parkingMapper.getCurrency().equals("SEK"))
			Currency="kr";
		else
			Currency=parkingMapper.getCurrency();
		
		ApcoaListeners.logInfo("Session ID in Expired session                      :"+SessionID);
		ApcoaListeners.logInfo("Total Cost in Expired session                      :"+TotalCost);
		ApcoaListeners.logInfo("Parking Name in Expired session                    :"+ParkingName);
		ApcoaListeners.logInfo("Vehicle number in Expired session                  :"+VehicleNum);
		if(!(Paymentcard==null))
		{ApcoaListeners.logInfo("Last digits of Payment Card  in Expired session    :"+Paymentcard);
		}
		ApcoaListeners.logInfo("Currency Symbol to be check in invoice             :"+Currency);
		
		System.out.println("");
		ApcoaListeners.logInfo("Going to download the Invoice PDF");
		CommonUtility.GenericMethods.explicitWait(driver,DownloadPDF,30);
		
		DownloadPDF.click();
		CommonUtility.GenericMethods.explicitWait(driver,DownloadInvoice,30);
		DownloadInvoice.click();
		Thread.sleep(4000);
		ApcoaListeners.logInfo("Scrolling Down the Notification");
		action.press(PointOption.point(277, 8)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(200))).moveTo(PointOption.point(258, 442)).release().perform();
		
		ApcoaListeners.logInfo("Getting the PDF number");
		CommonUtility.GenericMethods.explicitWait(driver,PDFName,30);
		PDFNumber=PDFName.getText();
		ApcoaListeners.logInfo("Invoice Number"+PDFNumber);
		Thread.sleep(4000);
		
		CommonUtility.GenericMethods.explicitWait(driver,closeallnotification,30);
		closeallnotification.click();
		
		((AndroidDriver<WebElement>) driver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
		
		VerifyPDF VP=new VerifyPDF();
		String PDF=VP.SendPDF(PDFNumber);
		
		System.out.println(PDF);
		ApcoaListeners.logInfo("Checking the Data in the Invoice PDF..............");
		SA.assertTrue(PDF.contains(TotalCost),"Total Cost is different or Not found");
		if(!(Paymentcard==null))
		{SA.assertTrue(PDF.contains(Paymentcard),"Payment Card Number Not Found ");}
		SA.assertTrue(PDF.contains(VehicleNum),"Vehicle Number is different or Not found");
		SA.assertTrue(PDF.contains(ParkingName),"Parking Name is different or Not found");
		SA.assertTrue(PDF.contains(Currency),"Currency Symbol is different or Not found");
		
		
		SA.assertAll();
		
	}

}
