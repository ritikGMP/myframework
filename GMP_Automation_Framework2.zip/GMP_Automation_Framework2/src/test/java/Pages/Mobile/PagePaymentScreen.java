package Pages.Mobile;

import java.time.Duration;
import java.util.List;

import org.apache.struts.action.Action;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;


import CommonUtility.CreateSession;
import TestNGListeners.ApcoaListeners;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class PagePaymentScreen {

	WebDriver driver;
	
	
	

	By ProfileList = By.className("android.widget.TextView");
	By ProfileName = By.xpath("//android.widget.TextView[contains(@text,'Profile')]");
	By SubCorporate = By.className("android.widget.TextView");

	@iOSXCUITFindBy(xpath = "//XCUIElementTypePicker")
	WebElement iOSSelectCoorperate;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Done']")
	WebElement iOSDoneBtn;

	//@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_menu')]")
	//private WebElement ClickOnsideBar;

	@iOSXCUITFindBy(xpath = "//*[contains(@name,'Payment') or contains(@name,'payment')]")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_payments_nav')]")
	private WebElement paymentNav;


	@iOSXCUITFindBy(xpath = "//XCUIElementTypeSwitch")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/sc_make_default')]")
	private WebElement makingDefault;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='icn back']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_back')]")
	private WebElement GoBacktoSideBar;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Business Profile')]")
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Business Profile')]")
	private WebElement selectBusinessProfile;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='trash icon']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/iv_delete')]")
	private WebElement deleteProfile;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='PROCEED']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_positive_action_button')]")
	private WebElement ProceedBtn;


	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add a Parking Profile']")
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Add a parking profile') or contains(@text,'Add a Parking Profile')]")
	private WebElement AddBuisnessProfile;


	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add a Business Profile']")
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@resource-id,'id/tv_parking_type')]")
	private WebElement SelectBuisnessProfile;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='CONTINUE']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/btn_action')]")
	private WebElement confirmProfile;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[2]")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/et_corporate_id')]")
	private WebElement CorporateId;


	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'Add a Corporate Profile') or contains(@name,'Add a Parking Profile')]")
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Add a parking profile')]")
	private WebElement SelectAddProfile;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Add a Corporate Profile']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/sp_subcorporates')]")
	private WebElement SelectSubCorporate;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[1]")
	private WebElement IOSSelectSubCorporate;

	@iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[3]")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/email')]")
	private WebElement email;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='PROCEED']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_positive_action_button')]")
	private WebElement Proceed;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/et_email')]")
	private WebElement enterEmail;

	@iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='checkbox unchecked icon']")
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/cb_terms')]")
	private WebElement AcceptTerms;
    
	@AndroidFindBy(xpath="//android.widget.TextView[contains(@text,'Business Profile')]")
	private WebElement SelectBusinessProfile;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_add_payment_header')]")
	private WebElement AddCard;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'tpayPay-Common-Quad-Button-Button--end')])[2]")
	private WebElement PaymentCorrectbtn;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'tpayPay-Common-Quad-Button-Button--end')])")
	private WebElement PaymentIncorrectbtn;
	
	
	//id/tv_verification_pending
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_verification_pending')]")
	private WebElement PaymentVerification;
	@AndroidFindBy(xpath="//*[contains(@resource-id,':id/tv_verification_pending_or_failed')]")
	private WebElement FailedPaymentVerification;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,':id/cl_card_info')])[3]")
	private WebElement CardVerification;
	
	//

//	@AndroidFindBy(xpath="(//android.widget.TextView[contains(@resource-id,':id/tv_card_number')])")
//	private WebElement AddedCard;
	
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,':id/iv_delete')])")
	private WebElement DeleteCard;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,':id/actv_positive_button')])")
	private WebElement CnfDeleteCard;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,':id/actv_message1')])")
	private WebElement DefaultCheck;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,':id/actv_negative_button')])")
	private WebElement OKGotIt;
	
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'pm_cc')])")
	private WebElement AddCreditCard;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'creditCardNumber')])")
	private WebElement CardNUmber;
	
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'cardCVV')])")
	private WebElement CardCVV;
	
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'bill_addr1')])")
	private WebElement CardBillAddress;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'bill_city')])")
	private WebElement CardBillCity;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'bill_country')])")
	private WebElement CardBillCountry;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'id/text1')])[2]")
	private WebElement selectCardBillCountry;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'bill_phone')])")
	private WebElement phoneNumber;
	
	@AndroidFindBy(xpath="//android.widget.Button[contains(@text,'Make payment')]")
	private WebElement MakePayment;
	
	@AndroidFindBy(xpath="//android.widget.Button[contains(@text,'Accept')]")
	private WebElement Accept;
	
	
	@AndroidFindBy(xpath="//android.widget.Button[contains(@text,'Yes')]")
	private WebElement YesBtn;
	
	@AndroidFindBy(xpath="(//android.widget.TextView[contains(@resource-id,'id/tv_card_number')])[1]")
	private WebElement verifyAddedcard;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'WalletCreditCard_CardNumber')]")
	private WebElement addCardEvo;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'exptime1')]")
	private WebElement addMonthEvo;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'exptime2')]")
	private WebElement addYearEvo;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'WalletCreditCard_CardHolderFirstName')]")
	private WebElement CardHolderFirstNameEVO;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'WalletCreditCard_CardHolderLastName')]")
	private WebElement CardHolderLastNameEVO;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'WalletCreditCard_CardHolderMiddleName')]")
	private WebElement CardHolderMiddleNameEVO;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'btn_Save')]")
	private WebElement btnSave;
	
	@AndroidFindBy(xpath="//*[contains(@resource-id,'id/txt_add_payment')]")
	private WebElement paymentText;
    
	@AndroidFindBy(xpath="(//android.widget.EditText)[1]")
	private WebElement StripeCreditCard;
	
	@AndroidFindBy(xpath="(//android.widget.EditText)[2]")
	private WebElement StripeExpiry;
	
	@AndroidFindBy(xpath="(//android.widget.EditText)[3]")
	private WebElement StripeCvv;
	
	@AndroidFindBy(xpath="(//*[contains(@resource-id,'submit')])")
	private WebElement CardSubmit;
	

	
	SoftAssert SA=new SoftAssert();
	
	public PagePaymentScreen(WebDriver appiumDriver){
		this.driver = appiumDriver;
		PageFactory.initElements(new AppiumFieldDecorator (appiumDriver), this);
	
	}	


	public void changingDefaultProfile(String Profile) throws InterruptedException {
		ApcoaListeners.logInfo("Profile to be set Default  ------>"+Profile);
		//CommonUtility.GenericMethods.explicitWait(driver,ClickOnsideBar,30);
		//ClickOnsideBar.click();
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();

		CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
		paymentNav.click();
		Thread.sleep(4000);
		if(CreateSession.getAutomationConfiguration().Platform.equalsIgnoreCase("Android")) {
			List<WebElement> profile = this.driver.findElements(ProfileList);
			for(WebElement singleProfile : profile){
				if(singleProfile.getText().equalsIgnoreCase(Profile)){	
					ApcoaListeners.logInfo("Profile Selected :"+singleProfile.getText());
					singleProfile.click();
					break;
				}
			}
		}else {
			driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'"+Profile+"')]")).click();

		}
		CommonUtility.GenericMethods.explicitWait(driver,makingDefault,30);
		makingDefault.click();
		ApcoaListeners.logInfo("Set to default profile");
		Thread.sleep(2000);
		GoBacktoSideBar.click();
		Thread.sleep(2000);
		GoBacktoSideBar.click();
		ApcoaListeners.logInfo("Setting up  Default profile  done");
	}


	public void DeleteBuisnessProfile() throws InterruptedException{
		try {
			ApcoaListeners.logInfo("Going to Delete buisness profile");
			//CommonUtility.GenericMethods.explicitWait(driver,ClickOnsideBar,30);
			//ClickOnsideBar.click();
			PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
			pha.clickMenuBtn();
			Thread.sleep(2000);
			CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
			paymentNav.click();
			Thread.sleep(2000);
			selectBusinessProfile.click();
			CommonUtility.GenericMethods.explicitWait(driver,makingDefault,10);
			ApcoaListeners.logInfo("Making Default profile ");
			makingDefault.click();
			CommonUtility.GenericMethods.explicitWait(driver,deleteProfile,10);
			deleteProfile.click();
			Thread.sleep(2000);
			ProceedBtn.click();
			ApcoaListeners.logInfo("Profile Deleted");
		}catch(Exception e) {

		}
	}


	public void AddBuisnessprofile() throws InterruptedException{
		SoftAssert SA=new SoftAssert();
		ApcoaListeners.logInfo("Going Add Buisness Profile");
		CommonUtility.GenericMethods.explicitWait(driver,AddBuisnessProfile,30);
		AddBuisnessProfile.click();

		  try {
			  CommonUtility.GenericMethods.explicitWait(driver,SelectBuisnessProfile,30);
			SelectBuisnessProfile.click();
		} catch(Exception e) {}
		
		Thread.sleep(2000);
		ApcoaListeners.logInfo("Entering the Email id :  spoorthi@getmyparking.com");
		enterEmail.sendKeys("spoorthi@getmyparking.com");
		Thread.sleep(2000);
		ApcoaListeners.logInfo("Confirm the Profile Creation");
		confirmProfile.click();
		Thread.sleep(2000);

		SA.assertEquals(SelectBusinessProfile.getText(),"Business Profile");
		SA.assertAll();
		ApcoaListeners.logInfo("Buisness profile created Successfully!!");

		Thread.sleep(4000);
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));

	}


	public boolean DeleteCorporateProfile(String CorporateName) throws InterruptedException{ 
		try {
			ApcoaListeners.logInfo("Going to Delete Corporate profile");
			ApcoaListeners.logInfo("Corporate Profile to be Deleted   :"+CorporateName);
			//CommonUtility.GenericMethods.explicitWait(driver,ClickOnsideBar,30);
			//ClickOnsideBar.click();
			PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
			pha.clickMenuBtn();
			Thread.sleep(2000);
			CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
			paymentNav.click();
			Thread.sleep(2000);

			if(CreateSession.getAutomationConfiguration().Platform.equalsIgnoreCase("Android")) {
				List<WebElement> profile = this.driver.findElements(ProfileName);
				for(int i=0;i<profile.size();i++){
					if(profile.get(i).getText().equalsIgnoreCase(CorporateName)){
						ApcoaListeners.logInfo("Got the Profile  :"+CorporateName);
						profile.get(i).click();
						break;
					}
				}
			}else {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'"+CorporateName+"')]")).click();
			}
			CommonUtility.GenericMethods.explicitWait(driver,deleteProfile,10);
			deleteProfile.click();

			Thread.sleep(2000);
			ProceedBtn.click();
			ApcoaListeners.logInfo("Profile Deleted");

			Thread.sleep(6000);
			if(CreateSession.getAutomationConfiguration().Platform.equalsIgnoreCase("Android")) {
				List<WebElement> profile1 = this.driver.findElements(ProfileName);
				for(int i=0;i<profile1.size();i++){
					if(profile1.get(i).getText().equalsIgnoreCase(CorporateName)){
						return false;
					}
				}
			}else {
				if(driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'"+CorporateName+"')]")).getText().length()>0) {
					return false;
				}
			}
		}catch(Exception e) {
			return false;
		}
		return true;
	}

	public boolean AddCorporateprofile(String CorporateProfile,String corporateId,String EmailId) throws InterruptedException{
		ApcoaListeners.logInfo("Going Add Corporate Profile");
		CommonUtility.GenericMethods.explicitWait(driver,SelectAddProfile,30);
		SelectAddProfile.click();
		CommonUtility.GenericMethods.explicitWait(driver,SelectSubCorporate,10);
		SelectSubCorporate.click();
		Thread.sleep(4000);
		ApcoaListeners.logInfo("Going To Select SubCorporate   :"+CorporateProfile);
		if(CreateSession.getAutomationConfiguration().Platform.equalsIgnoreCase("Android")) {
			List<WebElement> SP = this.driver.findElements(SubCorporate);
			for(int i=0;i<SP.size();i++){
				if(SP.get(i).getText().equalsIgnoreCase(CorporateProfile)){
					System.out.println(SP.get(i).getText());
					SP.get(i).click();
					break;
				}
			}
		}else {
			CommonUtility.GenericMethods.explicitWait(driver,iOSSelectCoorperate,10);
			IOSSelectSubCorporate.click();
			CommonUtility.GenericMethods.explicitWait(driver,iOSSelectCoorperate,10);
			//CorporateProfile = CorporateProfile.replaceAll(" ", "\\uFEFF");
			System.out.println(CorporateProfile);
			
			iOSSelectCoorperate.sendKeys(CorporateProfile);
			Thread.sleep(2000);
			iOSDoneBtn.click();
		}
		CommonUtility.GenericMethods.explicitWait(driver,CorporateId,30);
		CorporateId.sendKeys(corporateId);
		ApcoaListeners.logInfo("Corporate Id  :"+corporateId);

		CommonUtility.GenericMethods.explicitWait(driver,email,30);
		email.sendKeys(EmailId);
		ApcoaListeners.logInfo("Email Id  :"+EmailId);

		CommonUtility.GenericMethods.explicitWait(driver,AcceptTerms,30);
		AcceptTerms.click();
		ApcoaListeners.logInfo("Terms Accepted");

		CommonUtility.GenericMethods.explicitWait(driver,confirmProfile,30);
		confirmProfile.click();

		CommonUtility.GenericMethods.explicitWait(driver,Proceed,30);
		Proceed.click();


		Thread.sleep(8000);
		ApcoaListeners.logInfo("Checking Corporate Profile Added");
		List<WebElement> profile1 = this.driver.findElements(ProfileName);
		for(int i=0;i<profile1.size();i++){
			if(profile1.get(i).getText().equalsIgnoreCase(CorporateProfile+" Profile")){
				return true;
			}
		}
		return false;
	}
	
	
	public boolean TpayCardAddition(String type) throws InterruptedException
	{  
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();
		CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
		paymentNav.click();
		CommonUtility.GenericMethods.explicitWait(driver,AddCard,30);
		AddCard.click();
		Thread.sleep(5000);
		System.out.println("Swapping up");
	//	action.press(PointOption.point(481,1436)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(481,1012)).release().perform();
	//	action.press(PointOption.point(990, 660)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(200))).moveTo(PointOption.point(86, 660)).release().perform();
		TouchAction action = new TouchAction(CreateSession.getAutomationConfiguration().AppiumDriver);
		action.press(PointOption.point(479,1559)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(528,828)).release().perform();
		
		Thread.sleep(3000);
		System.out.println("Clicking on PaymentBtn");
		if(type.equalsIgnoreCase("Correct"))
		{CommonUtility.GenericMethods.explicitWait(driver,PaymentCorrectbtn,30);
		PaymentCorrectbtn.click();
		}
		else if(type.equalsIgnoreCase("Incorrect"))
		{
			CommonUtility.GenericMethods.explicitWait(driver,PaymentIncorrectbtn,30);
			PaymentIncorrectbtn.click();
		}
		Thread.sleep(3000);
		boolean res=checkTpay();
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	   return  res;	
	   
	}
	
	
	
	public boolean checkTpay()
	{  
		try {
		CommonUtility.GenericMethods.explicitWait(driver,PaymentVerification,30);
		System.out.println(PaymentVerification.getText());
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	public boolean VerifyTpayCard() throws InterruptedException
	{   
	Thread.sleep(45000);
	PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
    pha.clickMenuBtn();
    CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
	paymentNav.click();
		

		
		try {
			
		
		CommonUtility.GenericMethods.explicitWait(driver,PaymentVerification,10);
		
		System.out.println("false          "+PaymentVerification.getText());
		deleteCard();
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
		return false;
		}
		catch(Exception e)
		{  System.out.println("true");
			deleteCard();
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	       // Thread.sleep(30000);
			return true;
		}
	}
	
	public boolean VerifyFailedTpayCard() throws InterruptedException
	{   
	Thread.sleep(30000);
	PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
    pha.clickMenuBtn();
    CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
	paymentNav.click();
		

		
		try {
			
		
		CommonUtility.GenericMethods.explicitWait(driver,FailedPaymentVerification,10);
		
		System.out.println("true          "+FailedPaymentVerification.getText());
		//deleteCard();
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
		return true;
		}
		catch(Exception e)
		{  System.out.println("false");
			deleteCard();
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	       // Thread.sleep(30000);
			return false;
		}
	}
	
	
	
	By AddedCard = By.xpath("(//android.widget.TextView[contains(@resource-id,':id/tv_card_number')])");
	public void deleteCard()
	{ List<WebElement> Card = this.driver.findElements(AddedCard);
	  System.out.println(Card.size());
	  for(int i=0;i<Card.size();i++)
	  {
		  if(Card.get(i).getText().contains("3456")||Card.get(i).getText().contains("1111"))
		  {  CommonUtility.GenericMethods.explicitWait(driver,Card.get(i),10);
		     Card.get(i).click();
			  if(checkdelete())
			  {  
				  ((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
				  return;
			  }
			  
		  }
	  }
		
	}
	
	public Boolean checkdelete()
	{   
		
		CommonUtility.GenericMethods.explicitWait(driver,DeleteCard,10);
		DeleteCard.click();
		try {
		CommonUtility.GenericMethods.explicitWait(driver,CnfDeleteCard,5);
		CnfDeleteCard.click();
		}
		catch(Exception e)
		{
			
		}
		
		try {
			
			CommonUtility.GenericMethods.explicitWait(driver,DefaultCheck,15);
			CommonUtility.GenericMethods.explicitWait(driver,OKGotIt,10);
			OKGotIt.click();
			Thread.sleep(2000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
			System.out.println("Default card");
             return false;
		}
		catch(Exception e)
		{    
			return true;
		}
		
	}
	
	
	
	public void addTelrCard() throws InterruptedException
	{   SoftAssert SA=new SoftAssert();
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();
		ApcoaListeners.logInfo("GOING TO CLICK ON PAYMENT BUTTON");
		CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
		paymentNav.click();
		ApcoaListeners.logInfo("GOING TO ADD CARD");
		CommonUtility.GenericMethods.explicitWait(driver,AddCard,30);
		AddCard.click();
		//Thread.sleep(5000);
		CommonUtility.GenericMethods.explicitWait(driver,AddCreditCard,30);
		AddCreditCard.click();
		TouchAction action = new TouchAction(CreateSession.getAutomationConfiguration().AppiumDriver);
		action.press(PointOption.point(514,1692)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo(PointOption.point(486,1157)).release().perform();
		ApcoaListeners.logInfo("CARD NUMBER ----> 4111111111111111");
		CommonUtility.GenericMethods.explicitWait(driver,CardNUmber,30);
		CardNUmber.sendKeys("4111111111111111");
		ApcoaListeners.logInfo("CARD CVV----> 123");
		CommonUtility.GenericMethods.explicitWait(driver,CardCVV,30);
		CardCVV.sendKeys("123");
		
		CommonUtility.GenericMethods.explicitWait(driver,CardBillAddress,30);
		CardBillAddress.sendKeys("aabbccdd");
		CommonUtility.GenericMethods.explicitWait(driver,CardBillCity,30);
		CardBillCity.sendKeys("ssddff");
		CommonUtility.GenericMethods.explicitWait(driver,CardBillCountry,30);
		CardBillCountry.click();
		CommonUtility.GenericMethods.explicitWait(driver,selectCardBillCountry,30);
		selectCardBillCountry.click();
		CommonUtility.GenericMethods.explicitWait(driver,phoneNumber,30);
		phoneNumber.sendKeys("735735");
		ApcoaListeners.logInfo("CLICK ON MAKE PAYMENT");
		CommonUtility.GenericMethods.explicitWait(driver,MakePayment,30);
		
		MakePayment.click();
		Thread.sleep(10000);
		ApcoaListeners.logInfo("CLICK ON ACCEPT BUTTON");
		CommonUtility.GenericMethods.explicitWait(driver,Accept,30);
		Accept.click();
		Thread.sleep(10000);
		ApcoaListeners.logInfo("CLICK ON YES BUTTON");
		CommonUtility.GenericMethods.explicitWait(driver,YesBtn,30);
		YesBtn.click();
		SA.assertEquals(checkaddedcard(),true);
		SA.assertAll();
		ApcoaListeners.logInfo("DELETING THE CARD");
		deleteCard();
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
	}
	
	boolean checkaddedcard()
	{
		try {
			CommonUtility.GenericMethods.explicitWait(driver,verifyAddedcard,30);
			ApcoaListeners.logInfo("card is added succesfully !!");
			return true;
		}
		catch(Exception e)
		{   ApcoaListeners.logInfo("card not added succesfully");
			return false;
		}
	}
	
	
	public void addEvoCard() throws InterruptedException
	{
		 SoftAssert SA=new SoftAssert();
			PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
			pha.clickMenuBtn();
			ApcoaListeners.logInfo("GOING TO CLICK ON PAYMENT BUTTON");
			CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
			paymentNav.click();
			ApcoaListeners.logInfo("GOING TO ADD CARD");
			CommonUtility.GenericMethods.explicitWait(driver,AddCard,30);
			AddCard.click();
			
			Thread.sleep(25000);
			
			
			CommonUtility.GenericMethods.explicitWait(driver,addCardEvo,5);
			addCardEvo.sendKeys("4111111111111111");
			Thread.sleep(3000);
			CommonUtility.GenericMethods.explicitWait(driver,addMonthEvo,5);
			addMonthEvo.sendKeys("12");
			Thread.sleep(3000);
			CommonUtility.GenericMethods.explicitWait(driver,addYearEvo,5);
			addYearEvo.sendKeys("22");
			Thread.sleep(3000);
			CommonUtility.GenericMethods.explicitWait(driver,CardHolderFirstNameEVO,5);
			CardHolderFirstNameEVO.sendKeys("Amitasd");
			Thread.sleep(3000);
			CommonUtility.GenericMethods.explicitWait(driver,CardHolderFirstNameEVO,5);
			CardHolderLastNameEVO.sendKeys("Sharma");
			Thread.sleep(5000);
			CommonUtility.GenericMethods.explicitWait(driver,btnSave,5);
			 
			btnSave.click();
			Thread.sleep(2000);
			CommonUtility.GenericMethods.explicitWait(driver,paymentText,5);
			paymentText.click();
			Thread.sleep(5000);
			CommonUtility.GenericMethods.explicitWait(driver,addMonthEvo,5);
			addMonthEvo.clear();
			Thread.sleep(2000);
			addMonthEvo.sendKeys("11");
			CommonUtility.GenericMethods.explicitWait(driver,addYearEvo,5);
			addYearEvo.clear();
			Thread.sleep(2000);
			
			addYearEvo.click();
			Thread.sleep(2000);
			addYearEvo.sendKeys("25");
			Thread.sleep(2000);
		
			CommonUtility.GenericMethods.explicitWait(driver,btnSave,5);
			 
			btnSave.click();
			
//			CommonUtility.GenericMethods.explicitWait(driver,addCardEvo,5);
//			addCardEvo.clear();
//			try {
//			addCardEvo.sendKeys("4111111111111111");
//			
//			
//			Thread.sleep(2000);
//			CardHolderMiddleNameEVO.click();
			
			
//			CommonUtility.GenericMethods.explicitWait(driver,btnSave,5);
//			 
//			btnSave.click();
			
			System.out.println("Save button clicked");
			Thread.sleep(25000);
			
			
	}
	public void addstripe() throws InterruptedException
	{
		SoftAssert SA=new SoftAssert();
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();
		ApcoaListeners.logInfo("GOING TO CLICK ON PAYMENT BUTTON");
		CommonUtility.GenericMethods.explicitWait(driver,paymentNav,30);
		paymentNav.click();
		ApcoaListeners.logInfo("GOING TO ADD CARD");
		CommonUtility.GenericMethods.explicitWait(driver,AddCard,30);
		AddCard.click();
		
		//Thread.sleep(25000);
		
		CommonUtility.GenericMethods.explicitWait(driver,StripeCreditCard,20);
		StripeCreditCard.sendKeys("4111111111111111");
		CommonUtility.GenericMethods.explicitWait(driver,StripeExpiry,5);
		StripeExpiry.sendKeys("1225");
		CommonUtility.GenericMethods.explicitWait(driver,StripeCvv,5);
		StripeCvv.sendKeys("125");
		CommonUtility.GenericMethods.explicitWait(driver,CardSubmit,5);
		CardSubmit.click();
		
		
	}
	
	
	
	
	
	
}
