package Pages.Mobile;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import CommonUtility.CreateSession;
import TestNGListeners.ApcoaListeners;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PageSetting {

	WebDriver driver;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_settings')]")
	private WebElement BtnSetting;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/tv_legals')]")
	private WebElement BtnLegals;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/tv_terms')]")
	private WebElement BtnTermAndCond;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_privacy_policy')]")
	private WebElement BtnPrivacy;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_imprint')]")
	private WebElement BtnImprint;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_address')]")
	private WebElement ImprintText1;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_post')]")
	private WebElement ImprintText2;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/tv_contact_us')]")
	private WebElement BtnHelpAndSupport;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/btn_how_it_works')]")
	private WebElement BtnHowItWorks;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/onboarding_next')]")
	private WebElement BtnNext;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/onboarding_continue')]")
	private WebElement BtnNextContinue;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/btn_call_customer_support')]")
	private WebElement BtnCustomerSupport;

	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'id/search_action_text')]")
	private WebElement CheckDailerScreen;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/btn_message_customer_support')]")
	private WebElement BtnMessageSupport;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,'id/edt_message')]")
	private WebElement EditMessage;

	@AndroidFindBy(xpath = "//*[contains(@resource-id,':id/btn_send')]")
	private WebElement BtnSendMessage;

	public PageSetting(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public void NavigateToLegalsInSetting() {
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();

		CommonUtility.GenericMethods.explicitWait(driver, BtnSetting, 10);
		BtnSetting.click();
		CommonUtility.GenericMethods.explicitWait(driver, BtnLegals, 10);
		BtnLegals.click();
	}

	By TextLine = By.xpath("//android.widget.TextView");

	public boolean CheckTermAndCond() throws InterruptedException {
		CommonUtility.GenericMethods.explicitWait(driver, BtnTermAndCond, 10);
		BtnTermAndCond.click();
		List<WebElement> Text = this.driver.findElements(TextLine);
		if (Text.size() == 0)
			return false;

		for (int i = 0; i < Text.size(); i++) {
			if (Text.get(i).getText().toUpperCase().contains("APCOA")) {
				Thread.sleep(3000);
				((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
						.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

				return false;
			}

		}
		Thread.sleep(3000);
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
				.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

		return true;

	}

	public boolean CheckPrivacyPolicy() throws InterruptedException {
		CommonUtility.GenericMethods.explicitWait(driver, BtnPrivacy, 10);
		BtnPrivacy.click();
		List<WebElement> Text = this.driver.findElements(TextLine);
		if (Text.size() == 0)
			return false;

		for (int i = 0; i < Text.size(); i++) {
			if (Text.get(i).getText().toUpperCase().contains("APCOA")) {
				Thread.sleep(3000);
				((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
						.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

				return false;
			}

		}
		Thread.sleep(3000);
		((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
				.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

		return true;
	}

	public boolean CheckImprint() throws InterruptedException {
		CommonUtility.GenericMethods.explicitWait(driver, BtnImprint, 10);
		BtnImprint.click();
		if (ImprintText1.getText().toUpperCase().contains("APCOA")
				|| ImprintText2.getText().toUpperCase().contains("APCOA")) {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return false;
		} else {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return true;
		}

	}

	public void NavigateToHelpAndSupport() {
		PageHomeApcoa pha = new PageHomeApcoa(CreateSession.getAutomationConfiguration().AppiumDriver);
		pha.clickMenuBtn();
		CommonUtility.GenericMethods.explicitWait(driver, BtnHelpAndSupport, 10);
		BtnHelpAndSupport.click();
	}

	public void CheckHowWorks() throws InterruptedException {
		
		ApcoaListeners.logInfo("Checking The How Its Works");
		CommonUtility.GenericMethods.explicitWait(driver, BtnHowItWorks, 10);
		BtnHowItWorks.click();
		CommonUtility.GenericMethods.explicitWait(driver, BtnNext, 10);
		BtnNext.click();
		Thread.sleep(2000);
		CommonUtility.GenericMethods.explicitWait(driver, BtnNext, 10);
		BtnNext.click();
		Thread.sleep(2000);
		CommonUtility.GenericMethods.explicitWait(driver, BtnNextContinue, 10);
		BtnNextContinue.click();
		Thread.sleep(2000);
		CommonUtility.GenericMethods.explicitWait(driver, BtnNext, 10);
		BtnNext.click();
		CommonUtility.GenericMethods.explicitWait(driver, BtnNextContinue, 10);
		BtnNextContinue.click();
	}

	public boolean checkContactCustomerSupport() throws InterruptedException {
		ApcoaListeners.logInfo("Checking ContactCustomerSupport");
		CommonUtility.GenericMethods.explicitWait(driver, BtnCustomerSupport, 10);
		BtnCustomerSupport.click();

		CommonUtility.GenericMethods.explicitWait(driver, CheckDailerScreen, 10);
		if (CheckDailerScreen.getText().equalsIgnoreCase("Create new contact")) {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return true;

		} else {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver)
					.pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return false;
		}

	}

	public boolean MessageCustomerSupport() throws InterruptedException {
		
		ApcoaListeners.logInfo("Checking The Message Customer Support");
		CommonUtility.GenericMethods.explicitWait(driver, BtnMessageSupport, 10);
		BtnMessageSupport.click();
		CommonUtility.GenericMethods.explicitWait(driver, EditMessage, 10);
		EditMessage.sendKeys("Text for Testing");
		System.out.println(EditMessage.getText());
		
		if (BtnSendMessage.isEnabled() && EditMessage.getText().equalsIgnoreCase("Text for Testing")) {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return true;

		} else {
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));
			Thread.sleep(3000);
			((AndroidDriver<WebElement>) CreateSession.getAutomationConfiguration().AppiumDriver).pressKey(new KeyEvent().withKey(AndroidKey.BACK));

			return false;
			}

	}

}
